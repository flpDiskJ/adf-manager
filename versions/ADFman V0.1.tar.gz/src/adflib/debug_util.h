
#ifndef __ADFLIB_DEBUG_UTIL__
#define __ADFLIB_DEBUG_UTIL__

void adfPrintBacktrace ( void );

#endif
