To compile run the following:
	mkdir build  # create build dir
	cd build     # nav into build dir
	cmake ..     # generate makefile
	make         # compile program  
	./ADFman     # run program
